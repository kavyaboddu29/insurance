# SmartClaim AI - Automated Health Insurance Fraud Detection

## Steps to Run

1. Install requirements:
pip install -r requirements.txt

2. Generate dataset:
python generate_dataset.py

3. Train model:
python train_model.py

4. Run Streamlit app:
streamlit run app.py
