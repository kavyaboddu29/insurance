import streamlit as st
import pickle
import numpy as np

st.title("SmartClaim AI - Fraud Detection System")

model = pickle.load(open("fraud_model.pkl", "rb"))

st.header("Enter Claim Details")

age = st.number_input("Age", 18, 100)
gender = st.selectbox("Gender", ["Male", "Female"])
policy_duration_days = st.number_input("Policy Duration (days)", 1, 3000)
claim_amount = st.number_input("Claim Amount", 1000, 1000000)
previous_claims = st.number_input("Previous Claims", 0, 10)
days_since_last_claim = st.number_input("Days Since Last Claim", 0, 365)
hospital_risk_score = st.number_input("Hospital Risk Score", 1, 100)
treatment_type = st.selectbox("Treatment Type", ["Surgery", "Therapy", "Medication"])

gender = 1 if gender == "Male" else 0
treatment_map = {"Surgery": 0, "Therapy": 1, "Medication": 2}
treatment_type = treatment_map[treatment_type]

if st.button("Check Fraud Risk"):
    input_data = np.array([[age, gender, policy_duration_days, claim_amount,
                            previous_claims, days_since_last_claim,
                            hospital_risk_score, treatment_type]])
    
    probability = model.predict_proba(input_data)[0][1]
    risk_score = round(probability * 100, 2)
    
    st.subheader(f"Fraud Risk Score: {risk_score}%")
    
    if risk_score < 40:
        st.success("Low Risk - Genuine Claim")
    elif risk_score < 70:
        st.warning("Medium Risk - Needs Review")
    else:
        st.error("High Risk - Potential Fraud")
