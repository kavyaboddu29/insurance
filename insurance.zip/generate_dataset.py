import pandas as pd
import numpy as np

np.random.seed(42)
n = 1000

data = pd.DataFrame({
    "claim_id": range(1, n+1),
    "age": np.random.randint(18, 80, n),
    "gender": np.random.choice(["Male", "Female"], n),
    "policy_duration_days": np.random.randint(10, 2000, n),
    "claim_amount": np.random.randint(5000, 500000, n),
    "previous_claims": np.random.randint(0, 6, n),
    "days_since_last_claim": np.random.randint(1, 365, n),
    "hospital_risk_score": np.random.randint(1, 100, n),
    "treatment_type": np.random.choice(["Surgery", "Therapy", "Medication"], n)
})

data["fraud_label"] = np.where(
    ((data["policy_duration_days"] < 60) & (data["claim_amount"] > 200000)) |
    (data["previous_claims"] > 3) |
    (data["hospital_risk_score"] > 80),
    1, 0
)

data.to_csv("health_insurance_fraud_dataset.csv", index=False)
print("Dataset generated successfully!")
